:emx
:reset
	disconnect
